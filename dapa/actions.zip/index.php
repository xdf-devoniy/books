<?php include 'partials/header.php'; ?>
<h2>Hozirda mavjud Kitoblar: Harvard School</h2>
<form action="index.php" method="GET">
    <div class="form-group">
        <label for="date">Sana bo'yicha filtr:</label>
        <input type="date" class="form-control" id="date" name="date" required>
    </div>
    <button type="submit" class="btn btn-primary" style="margin-top:10px">Filter</button>
</form>

<table class="table table-striped mt-3">
    <thead>
        <tr>
            <th>Kitob nomi</th>
            <th>Soni</th>
            <th>Umumiy qiymati (UZS)</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include 'db.php';
        $date = isset($_GET['date']) ? $_GET['date'] : null;
        $query = "SELECT b.name, i.quantity, b.price FROM inventory i JOIN books b ON i.book_id = b.id";
        if ($date) {
            $query .= " WHERE i.added_date <= '$date'";
        }
        $result = $conn->query($query);
        $total_books = 0;
        $total_value = 0;
        while ($row = $result->fetch_assoc()) {
            $total_value_per_book = $row['quantity'] * $row['price'];
            echo "<tr><td>{$row['name']}</td><td>" . number_format($row['quantity']) . "</td><td>" . number_format($total_value_per_book) . "</td></tr>";
            $total_books += $row['quantity'];
            $total_value += $total_value_per_book;
        }
        ?>
    </tbody>
    <tfoot>
        <tr>
            <th>Umumiy Kitoblar soni</th>
            <th><?php echo number_format($total_books); ?></th>
            <th>Umumiy Qiymati: <?php echo number_format($total_value); ?></th>
        </tr>
    </tfoot>
</table>
<?php include 'partials/footer.php'; ?>
